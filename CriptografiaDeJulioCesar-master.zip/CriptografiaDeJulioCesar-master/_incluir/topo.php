<header>
    <div id="header_central">

    </div>
</header>