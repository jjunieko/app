<footer>
    <div id="footer_central">
        <p>© Copyright 2020 - All Rights Reserved - Fernando Aragão</p>
    </div>
</footer>