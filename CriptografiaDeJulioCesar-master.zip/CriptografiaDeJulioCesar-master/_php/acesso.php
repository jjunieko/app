<?php 
    $filename = "answer.php";
    $token = "e0098b7860b7ead2c664ed00a3385d94dc8b725e";
    $url_receber = "https://api.codenation.dev/v1/challenge/dev-ps/generate-data?token={$token}";
    $url_enviar = "https://api.codenation.dev/v1/challenge/dev-ps/submit-solution?token={$token}";
?>